// Check the documentation on "Environment-Specific Configuration".
export declare global {
  interface Window {
    env: any;
  }
}
