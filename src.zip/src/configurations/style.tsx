export default {
  colors: {
    barBackgroundColor: '#001529',
    leftBarIconColor: 'rgba(255,255,255,0.65)',
    leftBarSelectedIconColor: '#FFFFFF',
    leftBarSelectedBackgroundColor: '#00AEEF',
    textColor: 'rgba(255,255,255,0.65)',
  },
};
