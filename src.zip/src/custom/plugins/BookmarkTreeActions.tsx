/*******************************************************************************
 * (C) ActiveViam 2019
 * ALL RIGHTS RESERVED. This material is the CONFIDENTIAL and PROPRIETARY
 * property of ActiveViam. Any unauthorized use,
 * reproduction or transfer of this material is strictly prohibited
 *******************************************************************************/
/**
 *  In this file we create our own bookmark tree actions
 */
import React from "react";
import ReactDOM from "react-dom";
import _ from "lodash";

import showRemoteBookmarkModal from "./reporting/RemoteBookmarkPopup";
import showPdfExportModal from "./export/PdfExportPopup";
import ScheduleReportPopup from "./reporting/ScheduleReportPopup";

const isRunningInIframe = window.top !== window.self;

const remoteBookmarkAction = {
  key: "remote-bookmark",
  createProperties() {
    return {
      isAvailable({ actionSituation, node }) {
        return (
          actionSituation === "tree-handler" &&
          node !== undefined &&
          node.data !== undefined &&
          node.data.type === "bookmark" &&
          _.get(node.sourceObject, "id") !== undefined
        );
      },
      getCaption() {
        return { textPath: "remoteBookmark" };
      },
      getIconSrcKey() {
        return "common.link";
      },
      execute(event, { node }) {
        showRemoteBookmarkModal({ bookmarkId: node.sourceObject.id });
      }
    };
  }
};

const pdfExportAction = {
  key: "pdf-export",
  createProperties(parameters, activeUI) {
    return {
      isAvailable(payload) {
        return _.get(payload, ["node", "sourceObject", "type"]) === "container";
      },
      isDisabled() {
        // For the routing logic to work correctly and the PDF output to be good looking,
        // we only enable the action when the snippet is running in full page.
        return isRunningInIframe;
      },
      getIconSrcKey() {
        return "menuItem.icon.pdfExport";
      },
      getCaption() {
        return {
          text: isRunningInIframe
            ? "Open snippet in full page to export to PDF"
            : "Export to PDF"
        };
      },
      execute(event, payload) {
        const { id, name } = payload.node.sourceObject;
        showPdfExportModal({ activeUI, bookmarkId: id, bookmarkName: name });
      }
    };
  }
};

const scheduleReportAction = {
  key: "schedule-report",
  createProperties(parameters, activeUI) {
    return {
      isAvailable(payload) {
        return (
          _.get(payload, ["node", "sourceObject", "type"]) === "container" &&
          activeUI.security
            .getSortedRoles()
            .includes(window.env.reporting.schedulingRole)
        );
      },
      isDisabled() {
        // For the routing logic to work correctly and the PDF output to be good looking,
        // we only enable the action when the snippet is running in full page.
        return isRunningInIframe;
      },
      getIconSrcKey() {
        return "menuItem.icon.pdfExport";
      },
      getCaption() {
        return {
          text: isRunningInIframe
            ? "Open snippet in full page to schedule export"
            : "Schedule report"
        };
      },
      execute(event, payload) {
        const { id, name } = payload.node.sourceObject;
        if (window.scheduledReportComponent) {
          window.scheduledReportComponent.current.showModal();
        } else {
          window.scheduledReportComponent = React.createRef();
        }
        ReactDOM.render(
          <ScheduleReportPopup
            bookmarkId={id}
            bookmarkName={name}
            activeUI={activeUI}
            ref={window.scheduledReportComponent}
          />,
          document.getElementById("popup")
        );
      }
    };
  }
};

export { remoteBookmarkAction, pdfExportAction, scheduleReportAction };
