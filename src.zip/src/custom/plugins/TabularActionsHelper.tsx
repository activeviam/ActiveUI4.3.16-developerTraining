/*******************************************************************************
 * (C) ActiveViam 2019
 * ALL RIGHTS RESERVED. This material is the CONFIDENTIAL and PROPRIETARY
 * property of ActiveViam. Any unauthorized use,
 * reproduction or transfer of this material is strictly prohibited
 *******************************************************************************/
/**
 *  In this file we create our own tabular actions
 */
import _ from "lodash";

/**
 * Returns the column headers selected in the tabular widget
 * @param {Object} widgetApi
 * @return {Object} selected column headers
 */
const getSelectedCols = widgetApi => {
  const selectedColumnKeys = widgetApi.getSelectedColumnsKeys();
  if (selectedColumnKeys === undefined || selectedColumnKeys.length === 0) {
    return [];
  }
  return widgetApi
    .getRenderableHeaders()
    .filter(({ columnKey }) => selectedColumnKeys.includes(columnKey));
};

/**
 * Returns the column header caption
 * @param {String} header
 * @return {String} header caption
 */
const getHeaderCaption = header => header.captions.join(" ");

const dayToDayParseExpression = (mdxApi, header0, snd) =>
  mdxApi.parsing.parseExpression(
    `IIF ([${window.env.timeDimension}].[${
      window.env.timeHierarchy
    }].CurrentMember.${window.env.timeDirection} IS NULL, NULL, ${
      header0.value
    } - (${header0.value}, [${window.env.timeDimension}].[${
      window.env.timeHierarchy
    }].currentMember.${window.env.timeDirection}))`,
    snd.discovery,
    { cubeName: mdxApi.base.getCubeName(snd.statement) }
  );

const commonIsAvailable = (actionSituation, widgetApi, context) => {
  if (
    !(
      actionSituation === "tabular-handler" &&
      context !== undefined &&
      context.target === "header"
    )
  ) {
    return false;
  }
  const dateSource = widgetApi.getDataSource();
  if (!dateSource.usesMdx()) {
    return false;
  }
  const selectColumns = getSelectedCols(widgetApi);
  if (selectColumns.length !== 2) {
    return false;
  }
  const tableData = widgetApi.getData();
  // Check that each select column matches exactly one measure column in the data
  return selectColumns.every(
    ({ dataIndexes }) =>
      dataIndexes.length === 1 && tableData.headers[dataIndexes[0]].isNumeric
  );
};

const refreshMdxStatements = (widgetApi, mdxApi, cellProps) => {
  widgetApi.getDataSource().setMdx(
    mdxApi.transformStatement(
      widgetApi.getDataSource().getMdx(),
      widgetApi.getDataSource().getDiscovery(),
      selectStatement => {
        const selectStatementClone = _.cloneDeep(selectStatement);
        selectStatementClone.cellProps = cellProps;
        return selectStatementClone;
      }
    )
  );
};

/**
 *  Turns negative values in a table a different colour depending on cell properties (server side)
 *  @param {Object} tabularApi - the tabularApi Object
 *  @param {Boolean} colouredNegativeValues - whether values are currently red or not
 */
const showNegativeValuesDifferently = (
  tabularApi,
  colouredNegativeValues,
  mdxApi
) => {
  const dataSource = tabularApi.getDataSource();
  dataSource.setMdx(
    mdxApi.transformStatement(
      dataSource.getMdx(),
      dataSource.getDiscovery(),
      selectStatement => {
        const selectStatementClone = _.cloneDeep(selectStatement);
        if (colouredNegativeValues) {
          selectStatementClone.cellProps = selectStatementClone.cellProps.filter(
            item => !(item === "FORE_COLOR")
          );
        } else {
          selectStatementClone.cellProps.push("FORE_COLOR");
        }
        return selectStatementClone;
      }
    )
  );
};

/**
 * Returns the column headers selected in the tabular widget
 * @param {Object} widgetApi
 * @return {Array.<String>} array of headers
 */
const getSelectedColumns = widgetApi => {
  const selectedColumnKeys = widgetApi.getSelectedColumnsKeys();
  const selectColumns = widgetApi
    .getRenderableHeaders()
    .filter(({ columnKey }) => selectedColumnKeys.includes(columnKey));
  const ourSelectedColumnHeaders = [];
  selectColumns.forEach(col => ourSelectedColumnHeaders.push(col.columnKey));
  return ourSelectedColumnHeaders;
};

/**
 *  Removes the measures that aren't selected from the tabular headers
 *  @param {Object} tabularApi - the tabularApi Object
 */
const removeOtherColumns = (tabularApi, mdxApi) => {
  const selectedColumnsIds = getSelectedColumns(tabularApi);
  const dataSource = tabularApi.getDataSource();
  const { headers } = tabularApi.getData();
  // Find the SnD needed for the MDX API
  let statement = mdxApi.parsing.parseExpression(dataSource.getMdx());
  const discovery = dataSource.getDiscovery();
  // Loop through the headers, and remove the measures that aren't selected
  headers.forEach(h => {
    if (!selectedColumnsIds.includes(h.value)) {
      statement = mdxApi.tabular.removeHeader(
        { statement, discovery },
        h.value,
        headers,
        []
      ).newStatement;
    }
  });
  dataSource.setMdx(mdxApi.parsing.toString(statement));
};

export {
  getSelectedCols,
  getHeaderCaption,
  dayToDayParseExpression,
  commonIsAvailable,
  refreshMdxStatements,
  showNegativeValuesDifferently,
  removeOtherColumns
};
