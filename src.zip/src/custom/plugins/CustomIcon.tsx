import React from 'react'

// 7.1.1: TODO: create your own custom icon using svg representation
// refer to showcase example > Smiley Container
// <svg width="20px" height="20px">
//     <circle cx="10" cy="10" r="7" stroke={palette.icon.gray} strokeWidth="4" fill={palette.icon.primaryColor}/>
// </svg>
export const iconPlugin = {
    key: 'my-custom-icon',
};
