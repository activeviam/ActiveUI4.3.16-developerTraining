/*******************************************************************************
 * (C) ActiveViam 2019
 * ALL RIGHTS RESERVED. This material is the CONFIDENTIAL and PROPRIETARY
 * property of ActiveViam. Any unauthorized use,
 * reproduction or transfer of this material is strictly prohibited
 *******************************************************************************/
import React from "react";
import { TimePicker, Radio, Form, Select } from "antd";

import { REPEAT_FORMATS } from "./ReportingReduxStore";

const FormItem = Form.Item;
const { Option } = Select;

const scheduleTimeFormat = "HH:mm";
const scheduleMinuteStep = 5;

const daysOfTheWeek = [
  "Monday",
  "Tuesday",
  "Wednesday",
  "Thursday",
  "Friday",
  "Saturday",
  "Sunday"
];

// Style constants
const verticalRadioContainer: React.CSSProperties = {
  display: "flex",
  flexDirection: "column"
};

const verticalRadioStyle: React.CSSProperties = {
  overflow: "hidden",
  height: "36px",
  lineHeight: "36px",
  margin: 0
};

const inlineWeekdayStyle: React.CSSProperties = {
  margin: "0 6px",
  width: "120px"
};

const inlineWeekdayTimeStyle: React.CSSProperties = {
  margin: "0 0 0 6px",
  width: "90px"
};

const parallelSelectorsGroup: React.CSSProperties = {
  display: "inline"
};

const newCronDaily = dailyTime => {
  const dailyTimeDate = dailyTime.toDate();
  return `00 ${dailyTimeDate.getMinutes()} ${dailyTimeDate.getHours()} * * *`;
};

const newCronWeekly = (weeklyDay, weeklyTime) => {
  const weeklyTimeDate = weeklyTime.toDate();
  return `00 ${weeklyTimeDate.getMinutes()} ${weeklyTimeDate.getHours()} * * ${weeklyDay}`;
};

const getReportCron = formValues => {
  let cronFormattedString = "";
  if (formValues.repeat === REPEAT_FORMATS.daily) {
    cronFormattedString = newCronDaily(formValues.repeatDailyTime);
  } else if (formValues.repeat === REPEAT_FORMATS.weekly) {
    cronFormattedString = newCronWeekly(
      formValues.repeatWeekday,
      formValues.repeatWeeklyTime
    );
  }
  return cronFormattedString;
};

interface RepeatDailyProps {
  form: any;
  repeatDailyTime?: any;
}
const RepeatDaily = (props: RepeatDailyProps) => (
  <Radio style={verticalRadioStyle} value="daily">
    Every day at
    {props.form.getFieldValue("repeat") === "daily"
      ? props.form.getFieldDecorator("repeatDailyTime", {
          initialValue: props.repeatDailyTime
        })(
          <TimePicker
            style={inlineWeekdayTimeStyle}
            format={scheduleTimeFormat}
            minuteStep={scheduleMinuteStep}
          />
        )
      : null}
  </Radio>
);

/* eslint-disable react/no-array-index-key */
interface RepeatWeeklyProps {
  form: any;
  repeatWeekday?: string;
  repeatWeeklyTime?: any;
}
const RepeatWeekly = (props: RepeatWeeklyProps) => (
  <Radio style={verticalRadioStyle} value="weekly">
    Weekly on
    {props.form.getFieldValue("repeat") === "weekly" ? (
      <div style={parallelSelectorsGroup}>
        {props.form.getFieldDecorator("repeatWeekday", {
          initialValue: props.repeatWeekday
        })(
          <Select style={inlineWeekdayStyle}>
            {Object.keys(daysOfTheWeek).map((day, index) => (
              <Option key={index} value={String(Number(day) + 1)}>
                {daysOfTheWeek[day]}
              </Option>
            ))}
          </Select>
        )}
        <span>at</span>
        {props.form.getFieldDecorator("repeatWeeklyTime", {
          initialValue: props.repeatWeeklyTime
        })(
          <TimePicker
            style={inlineWeekdayTimeStyle}
            format={scheduleTimeFormat}
            minuteStep={scheduleMinuteStep}
          />
        )}
      </div>
    ) : null}
  </Radio>
);
/* eslint-enable react/no-array-index-key */

interface RepeatOffProps {
  loadedRepeat: string;
}
const RepeatOff = (props: RepeatOffProps) => (
  <Radio
    style={verticalRadioStyle}
    value="off"
    disabled={props.loadedRepeat === "off"}
  >
    Stop scheduling this bookmark
  </Radio>
);

interface RepeatProps {
  form: any;
  repeatDailyTime?: any;
  repeatWeekday?: string;
  repeatWeeklyTime?: any;
  repeat: string;
  loadedRepeat: string;
}

const Repeat = (props: RepeatProps) => {
  const formItemLayout = {
    labelCol: {
      xs: { span: 24 },
      sm: { span: 6 }
    },
    wrapperCol: {
      xs: { span: 24 },
      sm: { span: 18 }
    }
  };

  return (
    <FormItem
      {...formItemLayout}
      className="UnifiedForm__Item"
      label="Generate"
    >
      {props.form.getFieldDecorator("repeat", {
        initialValue: props.repeat
      })(
        <Radio.Group style={verticalRadioContainer}>
          <RepeatDaily
            form={props.form}
            repeatDailyTime={props.repeatDailyTime}
          />
          <RepeatWeekly
            form={props.form}
            repeatWeekday={props.repeatWeekday}
            repeatWeeklyTime={props.repeatWeeklyTime}
          />
          <RepeatOff loadedRepeat={props.loadedRepeat} />
        </Radio.Group>
      )}
    </FormItem>
  );
};

export { Repeat, getReportCron };
