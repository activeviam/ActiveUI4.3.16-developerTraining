/*******************************************************************************
 * (C) ActiveViam 2019
 * ALL RIGHTS RESERVED. This material is the CONFIDENTIAL and PROPRIETARY
 * property of ActiveViam. Any unauthorized use,
 * reproduction or transfer of this material is strictly prohibited
 *******************************************************************************/
import React from "react";
import PropTypes from "prop-types";
import { Modal } from "antd";

const { info } = Modal;

const RemoteBookmarkPopup = ({ url }) => (
  <div>
    <span>URL: </span>
    <a href={url} target="_blank" rel="noopener noreferrer">
      {url}
    </a>
  </div>
);
RemoteBookmarkPopup.propTypes = {
  url: PropTypes.string.isRequired
};

const showRemoteBookmarkModal = ({ bookmarkId }) => {
  const url = `${window.location.origin}${
    window.location.pathname
  }#/export/${bookmarkId}`;
  info({
    title: "Open Bookmark",
    content: <RemoteBookmarkPopup url={url} />,
    maskClosable: true,
    mask: false
  });
};

export default showRemoteBookmarkModal;
