/*******************************************************************************
 * (C) ActiveViam 2019
 * ALL RIGHTS RESERVED. This material is the CONFIDENTIAL and PROPRIETARY
 * property of ActiveViam. Any unauthorized use,
 * reproduction or transfer of this material is strictly prohibited
 *******************************************************************************/
import React from "react";
import _ from "lodash";
import { Radio, Form, Input, Select } from "antd";

const FormItem = Form.Item;
const { Option } = Select;

export const standardPaperFormats = {
  letter: "US letter",
  a3: "A3",
  a4: "A4",
  a5: "A5"
};

export const specialWidthRadioGroup: React.CSSProperties = {
  width: "calc(100% - 5px)",
  marginLeft: "5px"
};

export const customRadioButton: React.CSSProperties = {
  width: "50%",
  textAlign: "center"
};

export const PAPER_FORMAT_CUSTOM = "custom";

const getReportPaper = formValues =>
  formValues.paperFormat === PAPER_FORMAT_CUSTOM
    ? _.fromPairs(
        ["height", "width"].map(dimension => [
          dimension,
          `${_.trimEnd(formValues[`paper${_.camelCase(dimension)}`], "px")}px`
        ])
      )
    : {
        format: formValues.paperFormat,
        landscape: formValues.paperLandscape
      };

/* eslint-disable react/no-array-index-key */
interface PaperFormatSelectorProps {
  form: any;
  formHalfWidthLayout: any;
  paper?: any;
}
const PaperFormatSelector = (props: PaperFormatSelectorProps) => (
  <FormItem
    {...props.formHalfWidthLayout}
    className="UnifiedForm__Item"
    label="Format"
  >
    {props.form.getFieldDecorator("paperFormat", {
      initialValue: props.paper.format || PAPER_FORMAT_CUSTOM
    })(
      <Select>
        <Option value={PAPER_FORMAT_CUSTOM}>Custom</Option>
        {Object.keys(standardPaperFormats).map((paperType, index) => (
          <Option key={index} value={paperType}>
            {standardPaperFormats[paperType]}
          </Option>
        ))}
      </Select>
    )}
  </FormItem>
);
/* eslint-enable react/no-array-index-key */

/* eslint-disable react/no-array-index-key */
interface PaperFormatProps {
  form: any;
  formDimensionsLayout: any;
  paper?: any;
}
const PaperFormatLayout = (props: PaperFormatProps) =>
  // Show dimensions for custom format, orientation selector otherwise
  props.form.getFieldValue("paperFormat") === PAPER_FORMAT_CUSTOM ? (
    <div className="UnitedFormMulti__Container">
      {["width", "height"].map((dimension, index) => (
        <div className="UnitedFormMulti__Half" key={index}>
          <FormItem
            {...props.formDimensionsLayout}
            className="UnifiedForm__Item"
            label={dimension === "width" ? "W" : "H"}
          >
            {props.form.getFieldDecorator(`paper${_.camelCase(dimension)}`, {
              initialValue: props.paper[dimension] || ""
            })(<Input placeholder="800px" />)}
          </FormItem>
        </div>
      ))}
    </div>
  ) : (
    <FormItem className="UnifiedForm__Item">
      {props.form.getFieldDecorator(`paperLandscape`, {
        initialValue: props.paper.landscape === true
      })(
        <Radio.Group buttonStyle="solid" style={specialWidthRadioGroup}>
          <Radio.Button style={customRadioButton} value>
            Landscape
          </Radio.Button>
          <Radio.Button style={customRadioButton} value={false}>
            Portrait
          </Radio.Button>
        </Radio.Group>
      )}
    </FormItem>
  );
/* eslint-enable react/no-array-index-key */

const generateLayoutObject = (labelProportion, wrapperProportion) => ({
  labelCol: {
    xs: { span: 24 },
    sm: { span: labelProportion }
  },
  wrapperCol: {
    xs: { span: 24 },
    sm: { span: wrapperProportion }
  }
});

interface PaperProps {
  form: any;
  paper?: any;
}
const Paper = (props: PaperProps) => {
  const formHalfWidthLayout = generateLayoutObject(12, 12);
  const formDimensionsLayout = generateLayoutObject(8, 16);
  return (
    <div className="UnitedFormMulti__Container">
      <div className="UnitedFormMulti__Half">
        <PaperFormatSelector
          form={props.form}
          formHalfWidthLayout={formHalfWidthLayout}
          paper={props.paper}
        />
      </div>
      <div className="UnitedFormMulti__Half">
        <PaperFormatLayout
          form={props.form}
          formDimensionsLayout={formDimensionsLayout}
          paper={props.paper}
        />
      </div>
    </div>
  );
};

export { Paper, getReportPaper };
