/*******************************************************************************
 * (C) ActiveViam 2019
 * ALL RIGHTS RESERVED. This material is the CONFIDENTIAL and PROPRIETARY
 * property of ActiveViam. Any unauthorized use,
 * reproduction or transfer of this material is strictly prohibited
 *******************************************************************************/
import React from "react";
import { Form, Input } from "antd";

const FormItem = Form.Item;
const { TextArea } = Input;

interface EmailTargetProps {
  form: any;
  formItemLayout: any;
  emailTarget: string;
}
const EmailTarget = (props: EmailTargetProps) => (
  <FormItem {...props.formItemLayout} className="UnifiedForm__Item" label="To">
    {props.form.getFieldDecorator("emailTarget", {
      initialValue: props.emailTarget,
      rules: [
        {
          required: true,
          message: "Please input the receiver email!"
        }
      ]
    })(<Input placeholder="user@example.com" />)}
  </FormItem>
);

interface EmailSubjectProps {
  form: any;
  formItemLayout: any;
  emailSubject: string;
}
const EmailSubject = (props: EmailSubjectProps) => (
  <FormItem
    {...props.formItemLayout}
    className="UnifiedForm__Item"
    label="Subject"
  >
    {props.form.getFieldDecorator("emailSubject", {
      initialValue: props.emailSubject,
      rules: [
        {
          required: true,
          message: "Please input the email subject!"
        }
      ]
    })(<Input placeholder="My Scheduled Report" />)}
  </FormItem>
);

interface EmailContentProps {
  form: any;
  formItemLayout: any;
  emailContent: string;
}
const EmailContent = (props: EmailContentProps) => (
  <FormItem
    {...props.formItemLayout}
    className="UnifiedForm__Item"
    label="Content"
  >
    {props.form.getFieldDecorator("emailContent", {
      initialValue: props.emailContent
    })(<TextArea rows={3} placeholder="Your daily report is attached." />)}
  </FormItem>
);

interface EmailDetailsProps {
  form: any;
  name: string;
  emailTarget: string;
  emailSubject: string;
  emailContent: string;
}
const EmailDetails = (props: EmailDetailsProps) => {
  const formItemLayout = {
    labelCol: {
      xs: { span: 24 },
      sm: { span: 6 }
    },
    wrapperCol: {
      xs: { span: 24 },
      sm: { span: 18 }
    }
  };

  return (
    <div className="UnifiedForm__Shader">
      <div className="UnifiedForm__ReadOnly UnifiedForm__ReadOnly--Quarters">
        <span className="UnifiedForm__ReadOnly_Label">Bookmark:</span>
        <span className="UnifiedForm__ReadOnly_Value">{props.name}</span>
      </div>
      <EmailTarget
        form={props.form}
        formItemLayout={formItemLayout}
        emailTarget={props.emailTarget}
      />
      <EmailSubject
        form={props.form}
        formItemLayout={formItemLayout}
        emailSubject={props.emailSubject}
      />
      <EmailContent
        form={props.form}
        formItemLayout={formItemLayout}
        emailContent={props.emailContent}
      />
    </div>
  );
};

export default EmailDetails;
