/*******************************************************************************
 * (C) ActiveViam 2019
 * ALL RIGHTS RESERVED. This material is the CONFIDENTIAL and PROPRIETARY
 * property of ActiveViam. Any unauthorized use,
 * reproduction or transfer of this material is strictly prohibited
 *******************************************************************************/
import React from "react";
import { Form, Input } from "antd";

const FormItem = Form.Item;

interface ExistingTemplateProps {
  form: any;
  isExistingTemplate: boolean;
}
const ExistingTemplate = (props: ExistingTemplateProps) => {
  const { getFieldDecorator } = props.form;
  return (
    <FormItem style={{ display: "none" }}>
      {getFieldDecorator("isExistingTemplate", {
        initialValue: props.isExistingTemplate
      })(<Input style={{ display: "none" }} />)}
    </FormItem>
  );
};

interface AttachmentProps {
  form: any;
  attachmentName: string;
}
const Attachment = (props: AttachmentProps) => {
  const { getFieldDecorator } = props.form;
  const formItemLayout = {
    labelCol: {
      xs: { span: 24 },
      sm: { span: 6 }
    },
    wrapperCol: {
      xs: { span: 24 },
      sm: { span: 18 }
    }
  };
  return (
    <FormItem {...formItemLayout} className="UnifiedForm__Item" label="Name">
      {getFieldDecorator("attachmentName", {
        initialValue: props.attachmentName,
        rules: [
          {
            required: true,
            message: "Please provide the attachment name!"
          }
        ]
      })(<Input addonAfter=".pdf" placeholder="My_Scheduled_Report" />)}
    </FormItem>
  );
};

export { ExistingTemplate, Attachment };
