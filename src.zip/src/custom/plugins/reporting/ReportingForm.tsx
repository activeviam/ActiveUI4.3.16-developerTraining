/*******************************************************************************
 * (C) ActiveViam 2019
 * ALL RIGHTS RESERVED. This material is the CONFIDENTIAL and PROPRIETARY
 * property of ActiveViam. Any unauthorized use,
 * reproduction or transfer of this material is strictly prohibited
 *******************************************************************************/
import React from "react";
import { connect } from "react-redux";
import { Icon, Form, Modal } from "antd";

import { ExistingTemplate, Attachment } from "./ReportingFormElements";
import EmailDetails from "./ReportingFormEmail";
import { Repeat } from "./ReportingFormRepeat";
import { Paper } from "./ReportingFormPaper";

import { ReportingFormState } from "./ReportingReduxStore";
import { FormProps } from "antd/lib/form";

interface ReportingFormProps extends FormProps {
  bookmarkName: string;
  bookmarkId: string;
  uniqueClassName: string;
  visible: boolean;
  onCancel: any;
  onSubmit: any;
  name: string;
  emailTarget: string;
  emailSubject: string;
  emailContent: string;
  attachmentName: string;
  loadedRepeat: string;
  repeat: string;
  repeatDailyTime: any;
  repeatWeekday: string;
  repeatWeeklyTime: any;
  paper: any;
  isExistingTemplate: boolean;
}

const ReportingForm = (props: ReportingFormProps, ref) => {
  return (
    <Modal
      ref={ref}
      title="Schedule Report"
      className={props.uniqueClassName}
      wrapClassName={`wrap-${props.uniqueClassName}`}
      visible={props.visible}
      onCancel={props.onCancel}
      onOk={props.onSubmit}
      mask={false}
      bodyStyle={{ padding: "6px 18px" }}
    >
      <Form>
        <ExistingTemplate
          form={props.form}
          isExistingTemplate={props.isExistingTemplate}
        />
        <div className="UnifiedForm__Heading">
          <Icon type="mail" />
          <span>Email Details</span>
        </div>
        <EmailDetails
          form={props.form}
          name={props.name}
          emailTarget={props.emailTarget}
          emailSubject={props.emailSubject}
          emailContent={props.emailContent}
        />

        <div className="UnifiedForm__Heading">
          <Icon type="clock-circle" />
          <span>
            Schedule{" "}
            <em style={{ color: "slategrey" }}>
              {props.isExistingTemplate
                ? `- This will overwrite your existing ${props.loadedRepeat} schedule!`
                : undefined}
            </em>
          </span>
        </div>
        <div className="UnifiedForm__Shader">
          <Repeat
            form={props.form}
            repeatDailyTime={props.repeatDailyTime}
            repeatWeekday={props.repeatWeekday}
            repeatWeeklyTime={props.repeatWeeklyTime}
            repeat={props.repeat}
            loadedRepeat={props.loadedRepeat}
          />
        </div>
        <div className="UnifiedForm__Heading">
          <Icon type="paper-clip" />
          <span>Attachment Details</span>
        </div>
        <div className="UnifiedForm__Shader">
          <Attachment form={props.form} attachmentName={props.attachmentName} />
          <Paper form={props.form} paper={props.paper} />
        </div>
      </Form>
    </Modal>
  );
};

const WrappedReportingForm = Form.create({
  name: "form_in_modal"
})(React.forwardRef(ReportingForm));

const mapStateToProps = (state: ReportingFormState): ReportingFormState => {
  return state;
};

export default connect(mapStateToProps)(WrappedReportingForm);
