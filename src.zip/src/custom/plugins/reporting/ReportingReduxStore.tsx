/*******************************************************************************
 * (C) ActiveViam 2019
 * ALL RIGHTS RESERVED. This material is the CONFIDENTIAL and PROPRIETARY
 * property of ActiveViam. Any unauthorized use,
 * reproduction or transfer of this material is strictly prohibited
 *******************************************************************************/
import { createStore } from "redux";
import moment from "moment";

export const REPEAT_TIME_FORMAT = "HH:mm";
export const REPEAT_DEFAULT_TIME = "08:00";
export const REPEAT_FORMATS = {
  daily: "daily",
  weekly: "weekly",
  off: "off"
};

/*
 * action types
 */

export const NAME = "NAME";
export const EMAIL_TARGET = "EMAIL_TARGET";
export const EMAIL_SUBJECT = "EMAIL_SUBJECT";
export const EMAIL_CONTENT = "EMAIL_CONTENT";
export const ATTACHMENT_NAME = "ATTACHMENT_NAME";
export const LOADED_REPEAT = "LOADED_REPEAT";
export const REPEAT = "REPEAT";
export const REPEAT_DAILY_TIME = "REPEAT_DAILY_TIME";
export const REPEAT_WEEK_DAY = "REPEAT_WEEK_DAY";
export const REPEAT_WEEKLY_TIME = "REPEAT_WEEKLY_TIME";
export const PAPER = "PAPER";
export const EXISTING_TEMPLATE = "EXISTING_TEMPLATE";

export const RESET = "RESET";

export interface ReportingFormState {
  name: string;
  emailTarget: string;
  emailSubject: string;
  emailContent: string;
  attachmentName: string;
  loadedRepeat: string;
  repeat: string;
  repeatDailyTime: any;
  repeatWeekday: string;
  repeatWeeklyTime: any;
  paper: any;
  isExistingTemplate: boolean;
}

export interface ReportingAction {
  type: string;
  value: any;
}

export const reportingReducer = (
  state: ReportingFormState = {
    name: "",
    emailTarget: "",
    emailSubject: "",
    emailContent: "",
    attachmentName: "",
    loadedRepeat: "off",
    repeat: "off",
    repeatDailyTime: moment(REPEAT_DEFAULT_TIME, REPEAT_TIME_FORMAT),
    repeatWeekday: "1",
    repeatWeeklyTime: moment(REPEAT_DEFAULT_TIME, REPEAT_TIME_FORMAT),
    paper: {
      format: "a4",
      landscape: true
    },
    isExistingTemplate: false
  },
  action: ReportingAction
): ReportingFormState => {
  switch (action.type) {
    case NAME:
      return { ...state, name: action.value };
    case EMAIL_TARGET:
      return { ...state, emailTarget: action.value };
    case EMAIL_SUBJECT:
      return { ...state, emailSubject: action.value };
    case EMAIL_CONTENT:
      return { ...state, emailContent: action.value };
    case ATTACHMENT_NAME:
      return { ...state, attachmentName: action.value };
    case LOADED_REPEAT:
      return { ...state, loadedRepeat: action.value };
    case REPEAT:
      return { ...state, repeat: action.value };
    case REPEAT_DAILY_TIME:
      return { ...state, repeatDailyTime: action.value };
    case REPEAT_WEEK_DAY:
      return { ...state, repeatWeekday: action.value };
    case REPEAT_WEEKLY_TIME:
      return { ...state, repeatWeeklyTime: action.value };
    case PAPER:
      return { ...state, paper: action.value };
    case EXISTING_TEMPLATE:
      return { ...state, isExistingTemplate: action.value };
    default: {
      return state;
    }
  }
};

export interface State {
  formState: ReportingFormState;
}

export const rootReducer = (state, action) => {
  let newState = state;
  if (action.type === RESET) {
    newState = undefined;
  }

  return reportingReducer(newState, action);
};

const store = createStore(rootReducer);

export default store;
