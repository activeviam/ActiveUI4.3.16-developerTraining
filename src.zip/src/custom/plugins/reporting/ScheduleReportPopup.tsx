/*******************************************************************************
 * (C) ActiveViam 2019
 * ALL RIGHTS RESERVED. This material is the CONFIDENTIAL and PROPRIETARY
 * property of ActiveViam. Any unauthorized use,
 * reproduction or transfer of this material is strictly prohibited
 *******************************************************************************/
import _ from "lodash";
import React from "react";
import { Provider } from "react-redux";
import { ActiveUI } from "@activeviam/activeui-sdk";
import moment from "moment";

import { getUniqueClassName, setPopupAsFocused } from "../../utils/PopupUtils";
import {
  notificationPutQuery,
  notificationDeleteQuery
} from "../../utils/RestQuerier";

import store, {
  REPEAT_FORMATS,
  REPEAT_TIME_FORMAT,
  NAME,
  EMAIL_TARGET,
  EMAIL_SUBJECT,
  EMAIL_CONTENT,
  ATTACHMENT_NAME,
  LOADED_REPEAT,
  REPEAT,
  REPEAT_DAILY_TIME,
  REPEAT_WEEK_DAY,
  REPEAT_WEEKLY_TIME,
  PAPER,
  EXISTING_TEMPLATE,
  RESET
} from "./ReportingReduxStore";
import WrappedReportingForm from "./ReportingForm";
import { getReportCron } from "./ReportingFormRepeat";
import { getReportPaper } from "./ReportingFormPaper";

import "../../UnifiedFormClasses_AUI.css";

const PDF_EXT = ".pdf";
const JSON_EXT = ".json";
const SCHEDULE_CS_FOLDER = "/schedule";
const USERNAME_DEFAULT = "default";

interface ScheduleReportPopupState {
  uniqueClassName: string;
  visible: boolean;
  formRef: any;
}
interface ScheduleReportPopupProps {
  bookmarkName: string;
  bookmarkId: string;
  activeUI: ActiveUI;
}

class ScheduleReportPopup extends React.Component<
  ScheduleReportPopupProps,
  ScheduleReportPopupState
> {
  static isCron6EntriesValid(cronEntries) {
    const bounds = [[0, 59], [0, 59], [0, 23], [1, 31], [1, 12], [0, 7]];
    /* eslint-disable no-restricted-globals */
    for (const [idx, val] of cronEntries) {
      if (!val || val === "") return false;

      const parsed = /^[\d]+$/.test(val) ? parseInt(val, 10) : NaN; // Strict decimal conversion
      if (
        (isNaN(parsed) && !/^[\d/*\-,]+$/.test(val)) ||
        parsed < bounds[idx][0] ||
        parsed > bounds[idx][1]
      ) {
        return false;
      }
    }
    /* eslint-enable no-restricted-globals */
    return true;
  }

  static isCronValid(cronString) {
    let valid = false;
    if (typeof cronString === "string") {
      const ar = cronString.split(" ");
      if (ar.length === 6) {
        valid = ScheduleReportPopup.isCron6EntriesValid(ar.entries());
      }
      if (ar.length === 1 && ar[0] === "") {
        valid = true;
      }
    }
    return valid;
  }

  constructor(props) {
    super(props);

    this.state = {
      uniqueClassName: getUniqueClassName(),
      visible: true,
      formRef: undefined
    };
  }

  componentDidMount() {
    const { uniqueClassName } = this.state;
    setTimeout(() => setPopupAsFocused(uniqueClassName));
  }

  showModal = () => {
    this.setState({ visible: true });
    const { uniqueClassName } = this.state;
    setTimeout(() => setPopupAsFocused(uniqueClassName));
  };

  handleCancel = () => {
    this.setState({ visible: false });
    const { form } = this.state.formRef.props;
    form.resetFields();
    store.dispatch({ type: RESET });
  };

  getUsername = activeUI => {
    let username = window.env.reporting.schedulingImpersonateUser;
    if (username === USERNAME_DEFAULT) {
      username = activeUI.security.getUsername();
    }
    return username;
  };

  toScheduleFile = formValues => {
    const { bookmarkId, activeUI } = this.props;

    const url = `${window.location.origin}${window.location.pathname}#/export/${bookmarkId}`;

    return JSON.stringify({
      impersonate: {
        username: this.getUsername(activeUI)
      },
      task: {
        type: "report",
        payload: {
          reportPayload: {
            producer: {
              type: "pdf",
              payload: {
                urls: [url],
                paper: getReportPaper(formValues)
              }
            },
            consumer: {
              type: "mail",
              payload: {
                to: formValues.emailTarget,
                subject: formValues.emailSubject,
                content: formValues.emailContent,
                attachmentName: `${formValues.attachmentName}${PDF_EXT}`
              }
            }
          }
        }
      },
      schedule: {
        type: "cron",
        payload: {
          pattern: getReportCron(formValues)
        }
      }
    });
  };

  loadSchedulePayload = unserializedJson => {
    // Detect daily or weekly pattern
    const patternArray = unserializedJson.schedule.payload.pattern.split(" ");
    if (patternArray[5] === "*") {
      store.dispatch({ type: LOADED_REPEAT, value: REPEAT_FORMATS.daily });
      store.dispatch({ type: REPEAT, value: REPEAT_FORMATS.daily });
      store.dispatch({
        type: REPEAT_DAILY_TIME,
        value: moment(
          `${patternArray[2]}:${patternArray[1]}`,
          REPEAT_TIME_FORMAT
        )
      });
    } else {
      store.dispatch({ type: LOADED_REPEAT, value: REPEAT_FORMATS.weekly });
      store.dispatch({ type: REPEAT, value: REPEAT_FORMATS.weekly });
      store.dispatch({ type: REPEAT_WEEK_DAY, value: patternArray[5] });
      store.dispatch({
        type: REPEAT_WEEKLY_TIME,
        value: moment(
          `${patternArray[2]}:${patternArray[1]}`,
          REPEAT_TIME_FORMAT
        )
      });
    }
  };

  loadExistingState = file => {
    const unserializedJson = JSON.parse(file);
    const consumerPayload =
      unserializedJson.task.payload.reportPayload.consumer.payload;
    store.dispatch({ type: EMAIL_TARGET, value: consumerPayload.to });
    store.dispatch({ type: EMAIL_SUBJECT, value: consumerPayload.subject });
    store.dispatch({ type: EMAIL_CONTENT, value: consumerPayload.content });
    store.dispatch({
      type: ATTACHMENT_NAME,
      value: _.trimEnd(consumerPayload.attachmentName, PDF_EXT)
    });

    const producerPayload =
      unserializedJson.task.payload.reportPayload.producer.payload;
    store.dispatch({ type: PAPER, value: producerPayload.paper });

    this.loadSchedulePayload(unserializedJson);
  };

  loadFromExistingBookmark = async () => {
    const { bookmarkId, activeUI } = this.props;
    let file;
    try {
      file = await activeUI.queries.serversPool
        .getContentServer(window.env.serverUrls.content)
        .getFile([`..${SCHEDULE_CS_FOLDER}/${bookmarkId}${JSON_EXT}`]);
    } catch (error) {
      // eslint-disable-next-line no-console
      console.warn(
        `Cannot find any existing scheduling for bookmark '${bookmarkId}'. More likely normal.`
      );
    }
    store.dispatch({ type: EXISTING_TEMPLATE, value: file !== undefined });
    if (file !== undefined) {
      this.loadExistingState(file.entry.content);
    }
  };

  initReportDetails = () => {
    const { bookmarkName } = this.props;
    store.dispatch({ type: NAME, value: bookmarkName });
    store.dispatch({ type: EMAIL_SUBJECT, value: `${bookmarkName} Report` });
    store.dispatch({ type: ATTACHMENT_NAME, value: `${bookmarkName}_Report` });

    this.loadFromExistingBookmark();
  };

  handleSubmit = () => {
    const { bookmarkId, activeUI } = this.props;
    // FIXME not sure why I cannot get access to the form in a more simple way. Before it used to be formRef.props
    // I finally have a reference, now not sure how to get the best one for it work simply
    const { form } = this.state.formRef.props.children.props.children[0].props;

    form.validateFields((err, values) => {
      if (err) {
        return;
      }

      const scheduleFile = this.toScheduleFile(values);
      const payload = {
        owners: [window.env.reporting.schedulingRole],
        readers: [window.env.reporting.schedulingRole],
        content: scheduleFile,
        overwrite: values.isExistingTemplate
      };

      if (values.repeat !== REPEAT_FORMATS.off) {
        notificationPutQuery(
          activeUI,
          `${window.env.rest.contentServerFilesBaseUrl}${SCHEDULE_CS_FOLDER}/${bookmarkId}${JSON_EXT}`,
          payload,
          "Schedule Saved",
          "Couldn't Save Schedule"
        );
      } else if (values.isExistingTemplate) {
        notificationDeleteQuery(
          activeUI,
          `${window.env.rest.contentServerFilesBaseUrl}${SCHEDULE_CS_FOLDER}/${bookmarkId}${JSON_EXT}`,
          "Schedule Cancelled",
          "Couldn't Cancel Schedule"
        );
      }

      form.resetFields();
      store.dispatch({ type: RESET });
      this.setState({ visible: false });
    });
  };

  saveFormRef = formRef => {
    this.setState({ formRef: formRef });
  };

  render() {
    const { bookmarkName, bookmarkId } = this.props;
    const { uniqueClassName, visible } = this.state;
    if (visible) {
      this.initReportDetails();
    }
    return (
      <Provider store={store}>
        <WrappedReportingForm
          wrappedComponentRef={this.saveFormRef}
          bookmarkName={bookmarkName}
          bookmarkId={bookmarkId}
          uniqueClassName={uniqueClassName}
          visible={visible}
          onCancel={this.handleCancel}
          onSubmit={this.handleSubmit}
        />
      </Provider>
    );
  }
}

export default ScheduleReportPopup;
