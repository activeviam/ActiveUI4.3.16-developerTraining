/*******************************************************************************
 * (C) ActiveViam 2019
 * ALL RIGHTS RESERVED. This material is the CONFIDENTIAL and PROPRIETARY
 * property of ActiveViam. Any unauthorized use,
 * reproduction or transfer of this material is strictly prohibited
 *******************************************************************************/
import _ from "lodash";
import React from "react";
import { Input, Select, Radio } from "antd";
import PropTypes from "prop-types";

import {
  standardPaperFormats,
  specialWidthRadioGroup,
  customRadioButton,
  PAPER_FORMAT_CUSTOM
} from "../reporting/ReportingFormPaper";

const { Option } = Select;
const RadioButton = Radio.Button;

export const PDF_EXTENSION = ".pdf";

const AttachmentFilename = ({ name, setName }) => (
  <Input
    style={{ width: "100%", marginBottom: 8 }}
    addonAfter={PDF_EXTENSION}
    onChange={({ target: { value } }) => {
      setName(value);
    }}
    placeholder="My_Report"
    defaultValue={name}
  />
);

AttachmentFilename.propTypes = {
  name: PropTypes.string.isRequired,
  setName: PropTypes.func.isRequired
};

/* eslint-disable react/no-array-index-key */
const PaperFormatSelector = ({ paper, setPaper, owner }) => (
  <Select
    style={{ width: "100%", marginBottom: 8 }}
    onChange={value => {
      const newPaper =
        value === PAPER_FORMAT_CUSTOM
          ? _.fromPairs(
              ["height", "width"].map(dimension => [
                dimension,
                `${window[`inner${_.capitalize(dimension)}`]}px`
              ])
            )
          : { format: value, landscape: true };
      setPaper(newPaper);
    }}
    value={paper.format || PAPER_FORMAT_CUSTOM}
  >
    <Option value={PAPER_FORMAT_CUSTOM}>Custom</Option>

    {Object.keys(standardPaperFormats).map(
      (paperType, index) => (
        <Option key={index} value={paperType}>
          {standardPaperFormats[paperType]}
        </Option>
      ),
      owner
    )}
  </Select>
);
/* eslint-enable react/no-array-index-key */

PaperFormatSelector.propTypes = {
  paper: PropTypes.object.isRequired,
  setPaper: PropTypes.func.isRequired,
  owner: PropTypes.object.isRequired
};

/* eslint-disable react/no-array-index-key */
const PaperFormatLayout = ({
  isUsingCustomFormat,
  paper,
  setCustomPaper,
  setLandscapePaper
}) => (
  <div>
    {/* Show dimensions for custom format, orientation selector otherwise */}
    {isUsingCustomFormat ? (
      <div style={{ display: "flex", width: "100%" }}>
        <div style={{ padding: 6 }}>W:</div>
        <Input
          style={{ width: "47%" }}
          placeholder="800px"
          value={paper.width || ""}
          onChange={({ target: { value } }) => {
            setCustomPaper("width", value);
          }}
        />
        <div style={{ padding: 6 }}>x</div>
        <div style={{ padding: 6 }}>H:</div>
        <Input
          style={{ width: "47%" }}
          placeholder="800px"
          value={paper.height || ""}
          onChange={({ target: { value } }) => {
            setCustomPaper("height", value);
          }}
        />
      </div>
    ) : (
      <Radio.Group
        buttonStyle="solid"
        onChange={({ target: { value } }) => {
          setLandscapePaper(value);
        }}
        style={specialWidthRadioGroup}
        value={paper.landscape}
      >
        <RadioButton style={customRadioButton} value>
          Landscape
        </RadioButton>
        <RadioButton style={customRadioButton} value={false}>
          Portrait
        </RadioButton>
      </Radio.Group>
    )}
  </div>
);
/* eslint-enable react/no-array-index-key */

PaperFormatLayout.propTypes = {
  isUsingCustomFormat: PropTypes.bool.isRequired,
  paper: PropTypes.object.isRequired,
  setCustomPaper: PropTypes.func.isRequired,
  setLandscapePaper: PropTypes.func.isRequired
};

export { AttachmentFilename, PaperFormatSelector, PaperFormatLayout };
