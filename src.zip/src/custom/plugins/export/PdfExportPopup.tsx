/*******************************************************************************
 * (C) ActiveViam 2019
 * ALL RIGHTS RESERVED. This material is the CONFIDENTIAL and PROPRIETARY
 * property of ActiveViam. Any unauthorized use,
 * reproduction or transfer of this material is strictly prohibited
 *******************************************************************************/
import React from "react";
import { Modal } from "antd";
import _ from "lodash";

import {
  AttachmentFilename,
  PaperFormatSelector,
  PaperFormatLayout,
  PDF_EXTENSION
} from "./PdfExportElements";

const { confirm } = Modal;

const downloadFile = url => {
  const link = document.createElement("a");
  link.href = url;
  link.setAttribute("style", "display:none");
  //link.style = { display: "none" };
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
};

interface PdfExportPopupProps {
  name: string;
  onChange: any;
  paper: any;
}

class PdfExportPopup extends React.Component<PdfExportPopupProps> {
  state = _.pick(this.props, ["name", "paper"]);

  handleChange = state => {
    // eslint-disable-next-line react/destructuring-assignment
    this.setState(state, () => this.props.onChange(this.state));
  };

  render() {
    const { state } = this;

    return (
      <div>
        <AttachmentFilename
          name={state.name}
          setName={v => this.handleChange({ name: v })}
        />
        <PaperFormatSelector
          paper={state.paper}
          setPaper={p => this.handleChange({ paper: p })}
          owner={this}
        />
        <PaperFormatLayout
          isUsingCustomFormat={!state.paper.format}
          paper={state.paper}
          setCustomPaper={(dim, v) =>
            this.handleChange({
              paper: Object.assign({}, state.paper, { [dim]: v })
            })
          }
          setLandscapePaper={v =>
            this.handleChange({
              paper: Object.assign({}, state.paper, {
                landscape: v
              })
            })
          }
        />
      </div>
    );
  }
}

/* eslint-disable max-lines-per-function,max-statements */
const showPdfExportModal = ({ activeUI, bookmarkId, bookmarkName }) => {
  let details = {
    name: bookmarkName,
    paper: {
      format: "a4",
      landscape: true
    }
  };

  confirm({
    title: "Export Bookmark to PDF",
    content: (
      <PdfExportPopup
        name={details.name}
        onChange={newDetails => {
          details = newDetails;
        }}
        paper={details.paper}
      />
    ),
    mask: false,
    icon: "file-pdf",
    okText: "Export",
    async onOk() {
      const { name, paper } = details;
      const url = `${window.location.origin}${
        window.location.pathname
      }#/export/${bookmarkId}`;
      const now = new Date();

      const contentServer = activeUI.queries.serversPool.getContentServer(
        window.env.serverUrls.content
      );
      try {
        const {
          data: { link }
        } = await contentServer.report({
          producer: {
            type: "pdf",
            payload: {
              urls: [url],
              paper
            }
          },
          consumer: {
            type: "download-link",
            payload: {
              filename: `${name} - ${now.toDateString()} ${now.toLocaleTimeString()}${PDF_EXTENSION}`
            }
          }
        });
        downloadFile(link);
      } catch (error) {
        // eslint-disable-next-line no-console
        console.error(error);
        alert(
          [
            "Failed to generate the report.",
            "Open the Web Console to see the error and make sure you are connected to a Content Server >= 5.6.4 with reporting REST services enabled.",
            "See https://support.activeviam.com/confluence/display/AP5/Reporting+and+scheduling"
          ].join("\n\n")
        );
      }
    }
  });
};
/* eslint-enable max-lines-per-function,max-statements */

export default showPdfExportModal;
