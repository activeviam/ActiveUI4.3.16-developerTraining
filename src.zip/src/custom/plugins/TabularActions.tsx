import {
  ActionPlugin,
  ExpressionNode,
  MdxUsingDataSource,
  SelectStatementNode,
  TabularHandlerActionPayload,
} from '@activeviam/activeui-sdk';
/*******************************************************************************
 * (C) ActiveViam 2019
 * ALL RIGHTS RESERVED. This material is the CONFIDENTIAL and PROPRIETARY
 * property of ActiveViam. Any unauthorized use,
 * reproduction or transfer of this material is strictly prohibited
 *******************************************************************************/
/**
 *  In this file we create our own tabular actions
 */
import showStatsModal from '../utils/Stats';

import {
  getSelectedCols,
  getHeaderCaption,
  dayToDayParseExpression,
  commonIsAvailable,
  refreshMdxStatements,
  showNegativeValuesDifferently,
  removeOtherColumns,
} from './TabularActionsHelper';

/**
 * For this action we need to know the Time/Date dimension and hierarchy, plus direction. This can be set as a variable in env.js
 */
const dayToDay: ActionPlugin = {
  key: 'day-to-day',
  createProperties(parameters, activeUI) {
    return {
      isAvailable({
        actionSituation,
        widgetApi,
        context,
      }: TabularHandlerActionPayload) {
        const selectColumns = getSelectedCols(widgetApi);
        if (selectColumns.length !== 1) {
          return false;
        }
        return (
          context !== undefined &&
          actionSituation === 'tabular-handler' &&
          widgetApi.getDataSource().usesMdx() &&
          context.renderableTabularHeader.columnKey.includes('[Measures]')
        );
      },
      getCaption({widgetApi}: TabularHandlerActionPayload) {
        return {textPath: 'computeDayToDay'};
      },
      getIconSrcKey() {
        return 'tree.icon.dashboard';
      },
      execute(event, {widgetApi, context}: TabularHandlerActionPayload) {
        const {mdx: mdxApi} = activeUI;
        const header0 = widgetApi.getData().headers[
          getSelectedCols(widgetApi)[0].dataIndexes[0]
        ];

        mdxApi.transformDataSource(
          widgetApi.getDataSource() as MdxUsingDataSource,
          snd => {
            const name = mdxApi.measures.createMeasure(
              `${getHeaderCaption(header0)}.D2D`,
            );
            const expression = dayToDayParseExpression(mdxApi, header0, snd);

            // Add the new measure using new calc member
            return mdxApi.measures.addMeasure(
              mdxApi.base.updateSnD(snd, statement =>
                mdxApi.formulas.addOrReplaceCalculatedMember(
                  statement,
                  name,
                  expression,
                  {
                    CAPTION: `"${getHeaderCaption(header0)}.D2D"`,
                    FORMAT_STRING: '"#,###.##"',
                  },
                ),
              ),
              name,
            );
          },
        );
      },
    };
  },
};

const computeDifference: ActionPlugin = {
  key: 'compute-difference',
  createProperties(parameters, activeUI) {
    return {
      isAvailable({
        actionSituation,
        widgetApi,
        context,
      }: TabularHandlerActionPayload) {
        return commonIsAvailable(actionSituation, widgetApi, context);
      },
      getCaption() {
        return {textPath: 'computeDifference'};
      },
      getIconSrcKey() {
        return 'menuItem.icon.calculate';
      },
      execute(event, {widgetApi}: TabularHandlerActionPayload) {
        const {mdx: mdxApi} = activeUI;
        const selectedColumns = getSelectedCols(widgetApi);
        const tableData = widgetApi.getData();
        const header0 = tableData.headers[selectedColumns[0].dataIndexes[0]];
        const header1 = tableData.headers[selectedColumns[1].dataIndexes[0]];
        let cellProps = [];

        mdxApi.transformDataSource(
          widgetApi.getDataSource() as MdxUsingDataSource,
          snd => {
            ({cellProps} = snd.statement as SelectStatementNode);
            const name = mdxApi.measures.createMeasure(
              `${getHeaderCaption(header0)}.Difference`,
            );
            const expression = mdxApi.parsing.parseExpression(
              `${header0.value} - ${header1.value}`,
              snd.discovery,
              {cubeName: mdxApi.base.getCubeName(snd.statement)},
            ) as ExpressionNode;

            // Add the new measure using new calc member
            return mdxApi.measures.addMeasure(
              mdxApi.base.updateSnD(snd, statement =>
                mdxApi.formulas.addOrReplaceCalculatedMember(
                  statement,
                  name,
                  expression,
                  {
                    CAPTION: `"Diff: ${getHeaderCaption(
                      header0,
                    )} and ${getHeaderCaption(header1)}"`,
                    FORMAT_STRING: '"#,###.##"',
                  },
                ),
              ),
              name,
            );
          },
        );

        refreshMdxStatements(widgetApi, mdxApi, cellProps);
      },
    };
  },
};

/**
 * The following two actions compute the sum and average between two columns.
 * Note, it only works for two. You could make this generic and work for more, or I will do it in the future.
 */
const computeSum: ActionPlugin = {
  key: 'compute-sum',
  createProperties(parameters, activeUI) {
    return {
      isAvailable({
        actionSituation,
        widgetApi,
        context,
      }: TabularHandlerActionPayload) {
        return commonIsAvailable(actionSituation, widgetApi, context);
      },
      getCaption({widgetApi}: TabularHandlerActionPayload) {
        return {textPath: 'computeSum'};
      },
      getIconSrcKey() {
        return 'menuItem.icon.calculate';
      },
      execute(event, {widgetApi}: TabularHandlerActionPayload) {
        const {mdx: mdxApi} = activeUI;
        const selectedColumns = getSelectedCols(widgetApi);
        const tableData = widgetApi.getData();
        const header0 = tableData.headers[selectedColumns[0].dataIndexes[0]];
        const header1 = tableData.headers[selectedColumns[1].dataIndexes[0]];

        mdxApi.transformDataSource(
          widgetApi.getDataSource() as MdxUsingDataSource,
          snd => {
            const name = mdxApi.measures.createMeasure(
              `${getHeaderCaption(header0)}+${getHeaderCaption(header1)}`,
            );
            const expression = mdxApi.parsing.parseExpression(
              `${header0.value} + ${header1.value}`,
              snd.discovery,
              {cubeName: mdxApi.base.getCubeName(snd.statement)},
            ) as ExpressionNode;

            // Add the new measure using new calc member
            return mdxApi.measures.addMeasure(
              mdxApi.base.updateSnD(snd, statement =>
                mdxApi.formulas.addOrReplaceCalculatedMember(
                  statement,
                  name,
                  expression,
                  {
                    CAPTION: `"Sum: ${getHeaderCaption(
                      header0,
                    )} and ${getHeaderCaption(header1)}"`,
                    FORMAT_STRING: '"#,###.##"',
                  },
                ),
              ),
              name,
            );
          },
        );
      },
    };
  },
};

const computeAvg: ActionPlugin = {
  key: 'compute-avg',
  createProperties(parameters, activeUI) {
    return {
      isAvailable({
        actionSituation,
        widgetApi,
        context,
      }: TabularHandlerActionPayload) {
        return commonIsAvailable(actionSituation, widgetApi, context);
      },
      getCaption({widgetApi}: TabularHandlerActionPayload) {
        return {textPath: 'computeAvg'};
      },
      getIconSrcKey() {
        return 'menuItem.icon.calculate';
      },
      execute(event, {widgetApi}: TabularHandlerActionPayload) {
        const {mdx: mdxApi} = activeUI;
        const selectedColumns = getSelectedCols(widgetApi);
        const tableData = widgetApi.getData();
        const header0 = tableData.headers[selectedColumns[0].dataIndexes[0]];
        const header1 = tableData.headers[selectedColumns[1].dataIndexes[0]];

        mdxApi.transformDataSource(
          widgetApi.getDataSource() as MdxUsingDataSource,
          snd => {
            const name = mdxApi.measures.createMeasure(
              `Avg. ${getHeaderCaption(header0)}+${getHeaderCaption(header1)}`,
            );
            const expression = mdxApi.parsing.parseExpression(
              `(${header0.value} + ${header1.value})/2`,
              snd.discovery,
              {cubeName: mdxApi.base.getCubeName(snd.statement)},
            ) as ExpressionNode;

            // Add the new measure using new calc member
            return mdxApi.measures.addMeasure(
              mdxApi.base.updateSnD(snd, statement =>
                mdxApi.formulas.addOrReplaceCalculatedMember(
                  statement,
                  name,
                  expression,
                  {
                    CAPTION: `"Avg: ${getHeaderCaption(
                      header0,
                    )} and ${getHeaderCaption(header1)}"`,
                    FORMAT_STRING: '"#,###.##"',
                  },
                ),
              ),
              name,
            );
          },
        );
      },
    };
  },
};

/**
 *  Function to create our tabular plugins.
 */
const statsMenu: ActionPlugin = {
  key: 'stats-menu',
  createProperties(parameters, activeUI) {
    return {
      isAvailable({
        actionSituation,
        widgetApi,
        context,
      }: TabularHandlerActionPayload) {
        return actionSituation === 'tabular-handler' && context !== undefined;
      },
      getCaption({widgetApi}: TabularHandlerActionPayload) {
        return {textPath: 'statsMenu'};
      },
      getIconSrcKey() {
        return 'tree.icon.dashboard';
      },
      execute(event, {widgetApi, context}: TabularHandlerActionPayload) {
        const nCols = widgetApi.getData().headers.length;
        const nRows = widgetApi.getData().content.length;
        showStatsModal({tableStats: [nCols, nRows]});
      },
    };
  },
};

const negativeValuesRender: ActionPlugin = {
  key: 'negative-values-render',
  createProperties(parameters, activeUI) {
    let statement;
    let colouredNegativeValues;
    return {
      isAvailable({
        actionSituation,
        widgetApi,
        context,
      }: TabularHandlerActionPayload) {
        const {mdx: mdxApi} = activeUI;
        let available = false;
        const mdxDatasource = widgetApi.getDataSource() as MdxUsingDataSource;
        if (
          actionSituation === 'tabular-handler' &&
          context !== undefined &&
          mdxDatasource.usesMdx()
        ) {
          statement = mdxApi.parsing.parseExpression(
            mdxDatasource.getMdx(),
            mdxDatasource.getDiscovery(),
          );
          if (statement.cellProps !== undefined) {
            colouredNegativeValues =
              statement.cellProps.find(element => element === 'FORE_COLOR') !==
              undefined;
            available = true;
          }
        }
        return available;
      },
      getCaption({widgetApi}: TabularHandlerActionPayload) {
        return colouredNegativeValues
          ? {textPath: 'negativeValuesNo'}
          : {textPath: 'negativeValuesYes'};
      },
      getIconSrcKey() {
        return 'button.view';
      },
      execute(event, {widgetApi, context}: TabularHandlerActionPayload) {
        const {mdx: mdxApi} = activeUI;
        showNegativeValuesDifferently(
          widgetApi,
          colouredNegativeValues,
          mdxApi,
        );
      },
    };
  },
};

const removeOthers: ActionPlugin = {
  key: 'remove-others',
  createProperties(parameters, activeUI) {
    return {
      isAvailable({
        actionSituation,
        widgetApi,
        context,
      }: TabularHandlerActionPayload) {
        return (
          context !== undefined &&
          context.target === 'header' &&
          actionSituation === 'tabular-handler' &&
          widgetApi !== undefined &&
          widgetApi.getData() !== undefined &&
          widgetApi.getDataSource !== undefined &&
          widgetApi.getDataSource().usesMdx()
        );
      },
      isDisabled({
        actionSituation,
        widgetApi,
        context,
      }: TabularHandlerActionPayload) {
        const {headers} = widgetApi.getData();
        // Loop through the headers, and check a measure is selected
        let disabled = false;
        headers.forEach(h => {
          if (!h.value.includes('[Measures]')) {
            disabled = true;
          }
        });
        return disabled;
      },
      getCaption({widgetApi}: TabularHandlerActionPayload) {
        return {textPath: 'removeOthersText'};
      },
      getIconSrcKey() {
        return 'menuItem.icon.delete';
      },
      execute(event, {widgetApi, context}: TabularHandlerActionPayload) {
        removeOtherColumns(widgetApi, activeUI.mdx);
      },
    };
  },
};

export const actions = [
  dayToDay,
  computeDifference,
  computeSum,
  computeAvg,
  removeOthers,
  negativeValuesRender,
  statsMenu,
];
