/*******************************************************************************
 * (C) ActiveViam 2019
 * ALL RIGHTS RESERVED. This material is the CONFIDENTIAL and PROPRIETARY
 * property of ActiveViam. Any unauthorized use,
 * reproduction or transfer of this material is strictly prohibited
 *******************************************************************************/
import _ from "lodash";

const antModalWrapClassName = "ant-modal-wrap";

const setPopupAsFocused = uniqueClassName => {
  // 1. Get all instances of modals
  const modals = document.getElementsByClassName(antModalWrapClassName);

  if (modals.length <= 1) {
    return;
  }

  // 2. Reset z-Index of all other modals
  _.forEach(modals, modal => {
    // eslint-disable-next-line no-param-reassign
    modal.style.zIndex = "";
  });

  // 3. Ensure that the popup that got clicked has the highest z-Index
  const modalToFocus = document.getElementsByClassName(
    `wrap-${uniqueClassName}`
  )[0];
  modalToFocus.setAttribute("style", "zIndex:1001");
  //modalToFocus.style.zIndex = 1001;
};

const getUniqueClassName = () => _.uniqueId("ant-modal-popup-");

export { getUniqueClassName, setPopupAsFocused };
