/*******************************************************************************
 * (C) ActiveViam 2019
 * ALL RIGHTS RESERVED. This material is the CONFIDENTIAL and PROPRIETARY
 * property of ActiveViam. Any unauthorized use,
 * reproduction or transfer of this material is strictly prohibited
 *******************************************************************************/
import { getQuery } from "./RestQuerier";

const setFile = data => {
  // This code was generously borrowed from: http://jsfiddle.net/a856P/51/
  // It might not be perfect but it works and was quick and easy.

  // Set data on blob.
  const blob = new Blob([data], { type: "text/plain;charset=UTF-8" });

  // Set view.
  if (blob) {
    // Read blob.
    const url = window.URL.createObjectURL(blob);

    // Create link.
    const a = document.createElement("a");
    // Set link on DOM.
    document.body.appendChild(a);
    // Set link's visibility.
    a.setAttribute("style", "display:none");
    //a.style = "display: none";
    // Set href on link.
    a.href = url;
    // Set file name on link.
    a.download = "project-bookmarks.json";

    // Trigger click of link.
    a.click();

    // Clear.
    window.URL.revokeObjectURL(url);
  }
};

/**
 * Exports bookmarks from a custom rest service on server. Must be enabled server side to work.
 */
const exportBookmarks = activeUI => {
  getQuery(activeUI, window.env.rest.contentServerFilesBaseUrl).then(d => {
    setFile(JSON.stringify(d));
  });
};

export default exportBookmarks;
