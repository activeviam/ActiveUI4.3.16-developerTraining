/*******************************************************************************
 * (C) ActiveViam 2019
 * ALL RIGHTS RESERVED. This material is the CONFIDENTIAL and PROPRIETARY
 * property of ActiveViam. Any unauthorized use,
 * reproduction or transfer of this material is strictly prohibited
 *******************************************************************************/
import React from "react";
import PropTypes from "prop-types";
import { Modal } from "antd";

const { info } = Modal;

/*
This is a really simple popup, which calculates the number of columns/rows in a table.
It is used as an example to show how easy it is to create a context menu, and use the API
*/

// create a settings popup
const StatsPopup = ({ tableStats }) => (
  <div>
    <div>
      <span>Number of columns: </span>
      <span>{tableStats[0]}</span>
    </div>
    <div>
      <span>Number of rows: </span>
      <span>{tableStats[1]}</span>
    </div>
  </div>
);

StatsPopup.propTypes = {
  tableStats: PropTypes.arrayOf(PropTypes.number).isRequired
};

const showStatsModal = ({ tableStats }) => {
  info({
    title: "Table statistics",
    content: <StatsPopup tableStats={tableStats} />,
    maskClosable: true,
    mask: false
  });
};

export default showStatsModal;
