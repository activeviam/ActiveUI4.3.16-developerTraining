/* eslint-disable max-statements */
export const applySmartFilteringDefaultSettings: any = (defaultSettings: any) => {
    let settings = defaultSettings;
    // Allow to inject the smart filtering settings from the env.js
    if (window.env.smartFiltering) {
      const smartFilteringSettings = {};
      if (window.env.smartFiltering.globallyDisabled) {
        smartFilteringSettings["memberSelection.smartFiltering"] = false;
      }
      const { disabledOnlyForHierarchies } = window.env.smartFiltering;
      if (
        disabledOnlyForHierarchies &&
        disabledOnlyForHierarchies.trim().length > 0
      ) {
        disabledOnlyForHierarchies.split(",").forEach(h => {
          smartFilteringSettings[
            `memberSelection.smartFiltering.${h.trim()}`
          ] = false;
        });
      }
      const { nonEmptyMeasure } = window.env.smartFiltering;
      if (nonEmptyMeasure && nonEmptyMeasure.trim().length > 0) {
        smartFilteringSettings[
          "memberSelection.smartFiltering.nonEmptyMeasure"
        ] = nonEmptyMeasure;
      }
  
      settings = Object.assign({}, smartFilteringSettings, settings);
    }
    return settings;
  }
  /* eslint-enable max-statements */

  export const applyActiveMonitorDefaultSettings: any = (defaultSettings: any) => {
    let settings = defaultSettings;
    if (!window.env.serverUrls.activeMonitor) {
      settings = Object.assign({}, settings, {
        "bookmarks.favorites.activemonitor-alert-list.hidden": true,
        "bookmarks.favorites.rules-editor.hidden": true,
        "bookmarks.favorites.parameter-list.hidden": true,
        "bookmarks.favorites.activemonitor-monitor-view.hidden": true,
        "bookmarks.favorites.activemonitor-monitor-list.hidden": true,
        "bookmarks.favorites.activemonitor-messages.hidden": true
      });
    }
    return settings;
  }