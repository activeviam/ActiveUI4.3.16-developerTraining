/*******************************************************************************
 * (C) ActiveViam 2019
 * ALL RIGHTS RESERVED. This material is the CONFIDENTIAL and PROPRIETARY
 * property of ActiveViam. Any unauthorized use,
 * reproduction or transfer of this material is strictly prohibited
 *******************************************************************************/
/*
  /!\ This code has to be reviewed as we have to pass the ActiveUI in each method
*/
import { notification } from "antd";

const { activePivot } = window.env.serverUrls;

/**
 * Authenticated POST query to the server with a payload
 * @param {ActiveUI} activeUI instance
 * @param {String} serviceUrl path
 * @param {String} acceptType accept type
 * @param {String} contentType content type
 * @param {String} method HTTP method
 * @param {Object} payload - JSON content to send to url
 * @return {Promise}
 */
/* eslint-disable max-params */
const queryPromise = (
  activeUI,
  serviceUrl,
  acceptType,
  contentType,
  method,
  payload
): Promise<Response> =>
  activeUI.security.getRequestOptions().then(requestOptions => {
    /* eslint-disable no-param-reassign */
    if (acceptType) {
      requestOptions.headers.append("Accept", acceptType);
    }
    if (contentType) {
      requestOptions.headers.append("Content-Type", contentType);
    }
    requestOptions.method = method;
    if (payload) {
      requestOptions.body = JSON.stringify(payload);
    }
    return fetch(`${activePivot}${serviceUrl}`, requestOptions);
    /* eslint-enable no-param-reassign */
  });
/* eslint-enable max-params */

/**
 * Authenticated POST query to the server with a payload
 * @param {ActiveUI} activeUI instance
 * @param {String} serviceUrl path
 * @param {Object} payload - JSON content to send to url
 * @return {Promise}
 */
const postQueryPromise = (activeUI, serviceUrl, payload): Promise<Response> =>
  queryPromise(
    activeUI,
    serviceUrl,
    "application/json",
    "application/json",
    "POST",
    payload
  );

/**
 * Authenticated POST query to the server with a payload
 * @param {ActiveUI} activeUI instance
 * @param {String} serviceUrl path
 * @param {Object} payload - JSON content to send to url
 * @return {Object} response data
 */
const postQuery: any = (activeUI, serviceUrl, payload) =>
  postQueryPromise(activeUI, serviceUrl, payload)
    .then(response => response.json())
    .then(result => result.data);

/**
 * Authenticated PUT query to the server with a payload
 * @param {ActiveUI} activeUI instance
 * @param {String} serviceUrl path
 * @param {Object} payload - JSON content to send to url
 * @return {Promise}
 */
const putQueryPromise = (activeUI, serviceUrl, payload): Promise<Response> =>
  queryPromise(
    activeUI,
    serviceUrl,
    "application/json",
    "application/json",
    "PUT",
    payload
  );

/**
 * Authenticated PUT query to the server with a payload
 * @param {ActiveUI} activeUI instance
 * @param {String} serviceUrl path
 * @param {Object} payload - JSON content to send to url
 * @return {Object} response data
 */
const putQuery: any = (activeUI, serviceUrl, payload) =>
  putQueryPromise(activeUI, serviceUrl, payload)
    .then(response => response.json())
    .then(result => result.data);

/**
 * Authenticated PUT query to the server with a payload and text response content
 * @param {ActiveUI} activeUI instance
 * @param {String} serviceUrl path
 * @param {Object} payload - Text content to send to url
 * @return {Object} response text
 */
const putQueryPlain = (activeUI, serviceUrl, payload) =>
  queryPromise(
    activeUI,
    serviceUrl,
    "text/plain",
    "application/json",
    "PUT",
    payload
  ).then(response => response.text());

/**
 * Authenticated PUT query to the server with a payload.
 * The result is displayed to the user through the notification mechanism.
 * @param {ActiveUI} activeUI instance
 * @param {String} serviceUrl path
 * @param {Object} payload - JSON content to send to url
 * @param {String} successMessage notification message in case of success
 * @param {String} errorMessage notification message in case of error
 */
/* eslint-disable max-params */
const notificationPutQuery = (
  activeUI,
  serviceUrl,
  payload,
  successMessage,
  errorMessage
) => {
  new Promise<Response>(resolve => {
    setTimeout(() => {
      resolve(putQueryPromise(activeUI, serviceUrl, payload));
    }, 500);
  }).then(
    resp => {
      if (resp.status >= 200 && resp.status < 300) {
        notification.success({
          message: successMessage
        });
      } else {
        notification.error({
          message: errorMessage,
          description: `Error on the server: ${resp.statusText}`
        });
      }
    },
    error => {
      notification.error({
        message: errorMessage,
        description: "There was an error on the server."
      });
      // eslint-disable-next-line
      console.error(error);
    }
  );
};
/* eslint-enable max-params */

/**
 * Authenticated GET query to the server
 * @param {ActiveUI} activeUI instance
 * @param {String} serviceUrl path
 */
const getQuery: any = (activeUI, serviceUrl) =>
  activeUI.security.getRequestOptions().then(requestOptions =>
    fetch(`${activePivot}${serviceUrl}`, requestOptions)
      .then(response => response.json())
      .then(result => result.data)
  );

/**
 * Authenticated DELETE query to the server
 * @param {ActiveUI} activeUI instance
 * @param {String} serviceUrl path
 * @return {Promise}
 */
const deleteQuery = (activeUI, serviceUrl) => {
  activeUI.security.getRequestOptions().then(requestOptions => {
    requestOptions.method = "DELETE"; // eslint-disable-line no-param-reassign
    return fetch(`${activePivot}${serviceUrl}`, requestOptions);
  });
};

/**
 * Authenticated DELETE query to the server
 * The result is displayed to the user through the notification mechanism.
 * @param {ActiveUI} activeUI instance
 * @param {String} serviceUrl path
 * @param {String} successMessage notification message in case of success
 * @param {String} errorMessage notification message in case of error
 */
/* eslint-disable max-params */
const notificationDeleteQuery = (
  activeUI,
  serviceUrl,
  successMessage,
  errorMessage
) => {
  new Promise(resolve => {
    setTimeout(() => {
      resolve(deleteQuery(activeUI, serviceUrl));
    }, 500);
  }).then(
    resp => {
      notification.success({
        message: successMessage
      });
    },
    error => {
      notification.error({
        message: errorMessage,
        description: "There was an error on the server."
      });
      // eslint-disable-next-line
      console.error(error);
    }
  );
};
/* eslint-enable max-params */

export {
  postQueryPromise,
  postQuery,
  putQueryPromise,
  putQuery,
  putQueryPlain,
  notificationPutQuery,
  getQuery,
  deleteQuery,
  notificationDeleteQuery
};
