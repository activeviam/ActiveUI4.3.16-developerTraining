/*******************************************************************************
 * (C) ActiveViam 2019
 * ALL RIGHTS RESERVED. This material is the CONFIDENTIAL and PROPRIETARY
 * property of ActiveViam. Any unauthorized use,
 * reproduction or transfer of this material is strictly prohibited
 *******************************************************************************/
import React from "react";
import PropTypes from "prop-types";
import { ActiveUI, useActiveUI, Container } from "@activeviam/activeui-sdk";

interface RemoteBookmarkProps {
  activeUI: ActiveUI;
  dashboardId: string;
}

class RemoteBookmark extends React.Component<RemoteBookmarkProps> {
  state = {
    value: null
  };

  async componentDidMount() {
    const { activeUI, dashboardId } = this.props;
    const value = await activeUI
      .getBookmarksApi(window.env.serverUrls.content)
      .getBookmark(dashboardId);
    this.setState({ value });
  }

  handleApiChange = async (activeUI, api) => {
    setTimeout(async () => {
      // eslint-disable-next-line no-console
      console.log("on API change");
      await activeUI.widgets.waitUntilAllLoaded();
      // At this point, the widgets are loaded and  their queries resolved
      // We still need to wait for the next render
      setTimeout(() => {
        window.renderComplete = true;
        // eslint-disable-next-line no-console
        console.log("render complete");
      });
    });
  };

  render() {
    const { activeUI, dashboardId } = this.props;
    const { value } = this.state;

    return value ? (
      <Container
        defaultValue={value}
        onApiChange={api => this.handleApiChange(activeUI, api)}
      />
    ) : (
      `Loading bookmark ${dashboardId} ...`
    );
  }
}

const ExportDashboard = ({ match }) => {
  const activeUI = useActiveUI();
  return (
    <RemoteBookmark
      activeUI={activeUI}
      dashboardId={match.params.dashboardId}
    />
  );
};

ExportDashboard.propTypes = {
  match: PropTypes.object.isRequired
};

export default ExportDashboard;
