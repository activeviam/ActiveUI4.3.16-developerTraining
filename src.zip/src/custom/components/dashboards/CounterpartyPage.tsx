// 6.1.3 TODO: add the page definition.
// 1. Take in a parameter counterparty
// 2. apply counterparty in the page filter
// 3. set counterparty as the page name
// you can copy the content and layout from the bookmark state of exercise 5.6
// Refer to showcase example > Story Telling with Dashboard Pages#pnlByDeskPage.
export const ctpyPage = (counterparty: string) => {
  return {
    // ...
  };
};